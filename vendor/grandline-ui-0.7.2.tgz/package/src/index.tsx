import { useEffect, useRef, useId, type ReactNode } from "react";
import "./styles.css";
export function CatalogueGrid({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`grandline-catalogue-grid ${className}`}>{children}</div>;
}
export function CatalogueCardFrame({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <article className={`grandline-catalogue-card ${className}`}>{children}</article>;
}
export { ListingProgress } from "./progress";

const dismissedWithoutStorage = new Set<string>();

export function WelcomeDialog({
  product,
  title,
  description,
  options,
  ready = true,
  signedIn = false,
  forceOpen = false,
  onChoose,
  onBrowse,
  browseIcon,
}: {
  product: string;
  title: string;
  description: string;
  options: Array<{ label: string; description: string; href: string; icon?: ReactNode }>;
  ready?: boolean;
  signedIn?: boolean;
  forceOpen?: boolean;
  onChoose?: (href: string) => void;
  onBrowse?: () => void;
  browseIcon?: ReactNode;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const titleId = useId();
  const descriptionId = useId();
  const selected = useRef(false);
  const previousForceOpen = useRef(forceOpen);
  const sessionKey = `grandline:welcome:${product}:dismissed`;
  useEffect(() => {
    const reopen = forceOpen && !previousForceOpen.current;
    previousForceOpen.current = forceOpen;
    if (!ready || signedIn || typeof window === "undefined") {
      if (dialog.current?.open) dialog.current.close?.();
      return;
    }
    let dismissed = dismissedWithoutStorage.has(sessionKey);
    try {
      dismissed = window.sessionStorage.getItem(sessionKey) === "1";
    } catch {
      // Keep navigation usable when browser storage is unavailable.
    }
    if (dismissed && !reopen) return;
    if (!dialog.current?.open) dialog.current?.showModal?.();
  }, [sessionKey, ready, signedIn, forceOpen]);
  function rememberDismissal() {
    try {
      window.sessionStorage.setItem(sessionKey, "1");
    } catch {
      dismissedWithoutStorage.add(sessionKey);
    }
  }
  function dismiss() {
    rememberDismissal();
    if (dialog.current?.open) dialog.current.close?.();
  }
  return (
    <dialog
      ref={dialog}
      aria-labelledby={titleId}
      aria-describedby={descriptionId}
      onClose={() => {
        if (!signedIn) rememberDismissal();
        if (!selected.current && !signedIn) onBrowse?.();
        selected.current = false;
      }}
      className="grandline-welcome"
    >
      <div className="grandline-welcome-inner">
        <button
          type="button"
          className="grandline-welcome-close"
          aria-label="Close welcome"
          onClick={() => dismiss()}
        >
          ×
        </button>
        <h2 id={titleId}>{title}</h2>
        <p id={descriptionId}>{description}</p>
        <div className="grandline-welcome-options">
          {options.map((option) => (
            <a
              key={option.label}
              href={option.href}
              onClick={() => {
                rememberDismissal();
                selected.current = true;
                onChoose?.(option.href);
                dismiss();
              }}
            >
              <span className="grandline-welcome-icon">{option.icon}</span>
              <span className="grandline-welcome-option-copy">
                <strong>{option.label}</strong>
                <span>{option.description}</span>
              </span>
            </a>
          ))}
        </div>
        <button
          type="button"
          aria-label="Just browsing"
          className="grandline-welcome-browse"
          onClick={() => dismiss()}
        >
          <span className="grandline-welcome-icon">{browseIcon}</span>
          <span className="grandline-welcome-option-copy">
            <strong>Just browsing</strong>
            <span>Explore Grandline at your own pace</span>
          </span>
        </button>
      </div>
    </dialog>
  );
}

export { Button, Field, ListingLayout, ReviewSection, ReviewFacts } from "./listing";
export { CatalogueImage, CatalogueCardBody, CatalogueTitle, CataloguePrice } from "./catalogue";
export { HeaderFrame, HeaderRow } from "./header";
