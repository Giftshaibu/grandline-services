import { type ImgHTMLAttributes, useEffect, useRef, useState } from "react";

/** A shared, keyboard-accessible viewer. Zoomed images scroll in both directions. */
export function ImageViewer({
  images,
  name,
  initialIndex,
  onClose,
}: {
  images: string[];
  name: string;
  initialIndex: number;
  onClose: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const viewport = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(initialIndex);
  const [zoom, setZoom] = useState(1);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const element = dialog.current!;
    const overflow = document.body.style.overflow;
    const previousFocus = document.activeElement;
    document.body.style.overflow = "hidden";
    element.showModal();
    return () => {
      element.close();
      document.body.style.overflow = overflow;
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected) previousFocus.focus();
    };
  }, []);
  useEffect(() => {
    setZoom(1);
    setFailed(false);
    if (viewport.current) {
      viewport.current.scrollLeft = 0;
      viewport.current.scrollTop = 0;
    }
  }, [active]);
  function move(delta: number) {
    setActive((current) => (current + delta + images.length) % images.length);
  }
  return (
    <dialog
      ref={dialog}
      className="grandline-image-viewer"
      aria-label={`${name} photos`}
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onKeyDown={(event) => {
        if (event.key === "ArrowLeft") {
          event.preventDefault();
          move(-1);
        }
        if (event.key === "ArrowRight") {
          event.preventDefault();
          move(1);
        }
      }}
    >
      <div className="grandline-image-toolbar">
        <span aria-live="polite">
          Photo {active + 1} of {images.length}
        </span>
        <div>
          <button
            type="button"
            aria-label="Zoom out"
            disabled={zoom <= 1 || failed}
            onClick={() => setZoom((value) => Math.max(1, value - 0.5))}
          >
            −
          </button>
          <button
            type="button"
            aria-label="Reset zoom"
            disabled={failed}
            onClick={() => setZoom(1)}
          >
            {Math.round(zoom * 100)}%
          </button>
          <button
            type="button"
            aria-label="Zoom in"
            disabled={zoom >= 4 || failed}
            onClick={() => setZoom((value) => Math.min(4, value + 0.5))}
          >
            +
          </button>
          <button type="button" onClick={onClose} aria-label="Minimise image viewer">
            Minimise
          </button>
          <button type="button" onClick={onClose} aria-label="Close image viewer">
            ✕
          </button>
        </div>
      </div>
      <div ref={viewport} className="grandline-image-viewport">
        {failed ? (
          <p role="status">Image unavailable. Try another photo.</p>
        ) : (
          <div
            className="grandline-image-canvas"
            style={{ width: `${zoom * 100}%`, height: `${zoom * 100}%` }}
          >
            <img
              key={images[active]}
              src={images[active]}
              alt={`${name}, photo ${active + 1}`}
              onError={() => setFailed(true)}
              draggable={false}
            />
          </div>
        )}
      </div>
      {images.length > 1 && (
        <div className="grandline-image-pagination">
          <button type="button" onClick={() => move(-1)}>
            Previous photo
          </button>
          <button type="button" onClick={() => move(1)}>
            Next photo
          </button>
        </div>
      )}
    </dialog>
  );
}

export function ZoomableImage({
  src,
  alt,
  className = "",
  onError,
  ...props
}: ImgHTMLAttributes<HTMLImageElement> & { src: string; alt: string }) {
  const [open, setOpen] = useState(false);
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);
  return (
    <div className={`grandline-zoomable-image ${className}`}>
      {failed ? (
        <p>Image unavailable</p>
      ) : (
        <img
          {...props}
          src={src}
          alt={alt}
          onError={(event) => {
            setFailed(true);
            onError?.(event);
          }}
        />
      )}
      {!failed && (
        <button
          type="button"
          className="grandline-image-expand"
          onClick={() => setOpen(true)}
          aria-label={`Maximise ${alt}`}
        >
          Maximise
        </button>
      )}
      {open && (
        <ImageViewer images={[src]} name={alt} initialIndex={0} onClose={() => setOpen(false)} />
      )}
    </div>
  );
}

export function ListingGallery({ images, name }: { images: string[]; name: string }) {
  const [active, setActive] = useState(0);
  const [open, setOpen] = useState(false);
  const [failed, setFailed] = useState<string[]>([]);
  const current = Math.min(active, Math.max(0, images.length - 1));
  return (
    <div className="grandline-listing-gallery">
      <div className="grandline-gallery-main">
        {images[current] && !failed.includes(images[current]!) ? (
          <>
            <img
              src={images[current]}
              alt={`${name}, photo ${current + 1}`}
              onError={() => setFailed((items) => [...items, images[current]!])}
            />
            <button
              type="button"
              className="grandline-image-expand"
              onClick={() => setOpen(true)}
              aria-label={`Maximise ${name} photo`}
            >
              ⛶ Maximise
            </button>
          </>
        ) : (
          <p>Image unavailable</p>
        )}
      </div>
      {images.length > 1 && (
        <div className="grandline-gallery-thumbnails" aria-label="Listing photos">
          {images.map((src, index) => (
            <button
              key={`${src}-${index}`}
              type="button"
              onClick={() => setActive(index)}
              aria-label={`Show photo ${index + 1}`}
              aria-pressed={current === index}
            >
              <img src={src} alt="" loading="lazy" />
            </button>
          ))}
        </div>
      )}
      {open && (
        <ImageViewer
          images={images}
          name={name}
          initialIndex={current}
          onClose={() => setOpen(false)}
        />
      )}
    </div>
  );
}
