import { useEffect, useRef, type ReactNode } from "react";
import "./styles.css";
export function CatalogueGrid({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={`grandline-catalogue-grid ${className}`}>{children}</div>;
}
export function CatalogueCardFrame({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <article className={`grandline-catalogue-card ${className}`}>{children}</article>;
}
export function ListingProgress({
  steps,
  current,
  onSelect,
}: {
  steps: string[];
  current: number;
  onSelect?: (step: number) => void;
}) {
  return (
    <nav aria-label="Listing progress" className="grandline-listing-progress">
      <ol>
        {steps.map((name, index) => (
          <li key={name}>
            <button
              type="button"
              disabled={!onSelect || index > current}
              aria-current={index === current ? "step" : undefined}
              onClick={() => onSelect?.(index)}
            >
              <span className="grandline-step-number">{index + 1}</span>
              <span>{name}</span>
            </button>
          </li>
        ))}
      </ol>
      <div
        role="progressbar"
        aria-valuemin={1}
        aria-valuemax={steps.length}
        aria-valuenow={current + 1}
        aria-label="Listing step"
        className="grandline-progress-track"
      >
        <span style={{ width: `${((current + 1) / steps.length) * 100}%` }} />
      </div>
    </nav>
  );
}

export function WelcomeDialog({
  product,
  title,
  description,
  options,
  ready = true,
  signedIn = false,
  forceOpen = false,
  onChoose,
  onBrowse,
}: {
  product: string;
  title: string;
  description: string;
  options: Array<{ label: string; description: string; href: string }>;
  ready?: boolean;
  signedIn?: boolean;
  forceOpen?: boolean;
  onChoose?: (href: string) => void;
  onBrowse?: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  const selected = useRef(false);
  useEffect(() => {
    if (!ready || signedIn || typeof window === "undefined") {
      if (dialog.current?.open) dialog.current.close?.();
      return;
    }
    try {
      if (!forceOpen && window.localStorage.getItem(`grandline_welcome_${product}`)) return;
    } catch {
      return;
    }
    if (!dialog.current?.open) dialog.current?.showModal?.();
  }, [product, ready, signedIn, forceOpen]);
  function dismiss() {
    try {
      window.localStorage.setItem(`grandline_welcome_${product}`, "seen");
    } catch {
      /* Continue browsing when storage is blocked. */
    }
    if (dialog.current?.open) dialog.current.close?.();
  }
  return (
    <dialog
      ref={dialog}
      onClose={() => {
        if (!selected.current && !signedIn) onBrowse?.();
        selected.current = false;
        dismiss();
      }}
      className="grandline-welcome"
    >
      <div className="grandline-welcome-inner">
        <button
          type="button"
          className="grandline-welcome-close"
          aria-label="Close welcome"
          onClick={() => dismiss()}
        >
          ×
        </button>
        <h2>{title}</h2>
        <p>{description}</p>
        <div className="grandline-welcome-options">
          {options.map((option) => (
            <a
              key={option.label}
              href={option.href}
              onClick={() => {
                selected.current = true;
                onChoose?.(option.href);
                dismiss();
              }}
            >
              <strong>{option.label}</strong>
              <span>{option.description}</span>
            </a>
          ))}
        </div>
        <button type="button" className="grandline-welcome-browse" onClick={() => dismiss()}>
          Just browsing
        </button>
      </div>
    </dialog>
  );
}
