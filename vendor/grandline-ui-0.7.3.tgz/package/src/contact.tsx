const grandlineContact = {
  phones: [
    { label: "+265 998 179 828", number: "+265998179828" },
    { label: "+265 997 539 393", number: "+265997539393" },
    { label: "+265 997 726 965", number: "+265997726965" },
  ],
  email: "grandlineautomw@gmail.com",
  website: "https://www.grandlineautomw.com",
};

export function GrandlineContactDetails({ headingLevel = 3 }: { headingLevel?: 2 | 3 }) {
  const Heading = headingLevel === 2 ? "h2" : "h3";
  return (
    <section className="grandline-contact-details" aria-label="Contact Grandline">
      <Heading>Contact Grandline</Heading>
      <address>
        <p>Call or WhatsApp</p>
        <ul>
          {grandlineContact.phones.map(({ label, number }) => (
            <li key={number}>
              <a href={`tel:${number}`} aria-label={`Call ${label}`}>
                {label}
              </a>
              <span aria-hidden="true"> · </span>
              <a
                href={`https://wa.me/${number.slice(1)}`}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={`WhatsApp ${label}`}
              >
                WhatsApp
              </a>
            </li>
          ))}
        </ul>
        <a href={`mailto:${grandlineContact.email}`}>{grandlineContact.email}</a>
        <a href={grandlineContact.website}>www.grandlineautomw.com</a>
      </address>
    </section>
  );
}
