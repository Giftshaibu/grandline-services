import type { ReactNode } from "react";

export function CatalogueCardBody({ children }: { children: ReactNode }) {
  return <div className="grandline-card-body">{children}</div>;
}
export function CatalogueTitle({ children }: { children: ReactNode }) {
  return <h3 className="grandline-card-title">{children}</h3>;
}
export function CataloguePrice({ children }: { children: ReactNode }) {
  return <span className="grandline-card-price">{children}</span>;
}

export function CatalogueImage({ src, alt }: { src?: string | undefined; alt: string }) {
  return (
    <div className="grandline-catalogue-media">
      <span aria-hidden="true">Image unavailable</span>
      {src && (
        <img
          key={src}
          src={src}
          alt={alt}
          loading="lazy"
          onError={(event) => {
            event.currentTarget.style.display = "none";
          }}
        />
      )}
    </div>
  );
}
