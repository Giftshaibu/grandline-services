import { cloneElement, type ButtonHTMLAttributes, type ReactElement, type ReactNode } from "react";
import { ListingProgress } from "./progress";

export function Button({
  className = "",
  variant = "primary",
  type = "button",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "text" }) {
  return (
    <button
      {...props}
      type={type}
      className={`grandline-button grandline-button-${variant} ${className}`}
    />
  );
}

export function Field({
  id,
  label,
  error,
  hint,
  children,
  onChange,
}: {
  id: string;
  label: ReactNode;
  error?: string | undefined;
  hint?: string | undefined;
  children: ReactElement;
  onChange?: (() => void) | undefined;
}) {
  const child = children as ReactElement<Record<string, unknown>>;
  const describedBy = [
    child.props["aria-describedby"],
    hint && `${id}-hint`,
    error && `${id}-error`,
  ]
    .filter(Boolean)
    .join(" ");
  return (
    <div className="grandline-field" onChange={onChange}>
      <label htmlFor={id}>{label}</label>
      {cloneElement(child, {
        id,
        className: `grandline-control ${child.props["className"] ?? ""}`,
        "aria-invalid": !!error,
        "aria-describedby": describedBy || undefined,
      })}
      {hint && (
        <p className="grandline-field-hint" id={`${id}-hint`}>
          {hint}
        </p>
      )}
      {error && (
        <p className="grandline-field-error" id={`${id}-error`}>
          {error}
        </p>
      )}
    </div>
  );
}

export function ListingLayout({
  steps,
  current,
  onSelect,
  children,
  savedNote,
}: {
  steps: string[];
  current: number;
  onSelect: (step: number) => void;
  children: ReactNode;
  savedNote?: string | undefined;
}) {
  return (
    <div className="grandline-listing-layout">
      <aside className="grandline-listing-sidebar">
        <h2>Your listing</h2>
        <p>Complete each section, then check everything before sending it for review.</p>
        <ListingProgress steps={steps} current={current} onSelect={onSelect} />
        <p className="grandline-step-caption" aria-live="polite">
          Step {current + 1} of {steps.length}
          {savedNote ? ` — ${savedNote}` : ""}
        </p>
      </aside>
      <div className="grandline-listing-content">{children}</div>
    </div>
  );
}

export function ReviewSection({
  title,
  step,
  edit,
  children,
}: {
  title: string;
  step: number;
  edit: (step: number) => void;
  children: ReactNode;
}) {
  return (
    <section className="grandline-review-section">
      <div className="grandline-review-heading">
        <h3>{title}</h3>
        <Button variant="text" onClick={() => edit(step)}>
          Edit {title.toLowerCase()}
        </Button>
      </div>
      {children}
    </section>
  );
}

export function ReviewFacts({ items }: { items: Array<[string, string]> }) {
  return (
    <dl className="grandline-review-facts">
      {items.map(([label, value]) => (
        <div key={label}>
          <dt>{label}</dt>
          <dd>{value || "Not supplied"}</dd>
        </div>
      ))}
    </dl>
  );
}
