import type { ReactNode } from "react";
import { UserButton } from "@clerk/tanstack-react-start";

export const accountAppearance = {
  elements: {
    avatarBox: "grandline-avatar",
    userButtonTrigger: "grandline-account-trigger",
  },
};

export function AccountMenu({
  links,
}: {
  links: Array<{ href: string; label: string; icon: ReactNode }>;
}) {
  return (
    <UserButton appearance={accountAppearance}>
      <UserButton.MenuItems>
        {links.map((link) => (
          <UserButton.Link
            key={link.href}
            href={link.href}
            label={link.label}
            labelIcon={link.icon}
          />
        ))}
      </UserButton.MenuItems>
    </UserButton>
  );
}
