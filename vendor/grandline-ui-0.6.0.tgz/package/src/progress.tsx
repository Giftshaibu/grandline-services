export function ListingProgress({
  steps,
  current,
  onSelect,
}: {
  steps: string[];
  current: number;
  onSelect?: (step: number) => void;
}) {
  return (
    <nav aria-label="Listing progress" className="grandline-listing-progress">
      <ol>
        {steps.map((name, index) => (
          <li key={name}>
            <button
              type="button"
              disabled={!onSelect || index > current}
              aria-current={index === current ? "step" : undefined}
              onClick={() => onSelect?.(index)}
            >
              <span className="grandline-step-number" data-complete={index < current}>
                {index < current ? "\u2713" : index + 1}
              </span>
              <span>{name}</span>
            </button>
          </li>
        ))}
      </ol>
      <div
        role="progressbar"
        aria-valuemin={1}
        aria-valuemax={steps.length}
        aria-valuenow={current + 1}
        aria-label="Listing step"
        className="grandline-progress-track"
      >
        <span style={{ width: `${((current + 1) / steps.length) * 100}%` }} />
      </div>
    </nav>
  );
}
