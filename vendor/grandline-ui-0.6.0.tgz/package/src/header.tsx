import type { ReactNode } from "react";

export function HeaderFrame({ children }: { children: ReactNode }) {
  return <header className="grandline-header">{children}</header>;
}
export function HeaderRow({ children }: { children: ReactNode }) {
  return <div className="grandline-header-row">{children}</div>;
}
